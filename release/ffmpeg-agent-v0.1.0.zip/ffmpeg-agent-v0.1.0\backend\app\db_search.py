import os, shutil, logging
from functools import lru_cache
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
from langchain_chroma import Chroma
from langchain_core.embeddings import Embeddings

load_dotenv()

logger = logging.getLogger(__name__)

DB_DIR = os.getenv('DB_DIR')
COLLECTION_NAME = os.getenv('COLLECTION_NAME')
PROBE_COLLECTION_NAME = os.getenv('PROBE_COLLECTION_NAME', 'ffprobe_docs')
BGE_CACHE_DIR = os.getenv('BGE_CACHE_DIR', 'backend/data/bge_small')
BGE_MODEL_NAME = os.getenv('BGE_MODEL_NAME', 'BAAI/bge-small-zh-v1.5')
HF_ENDPOINT = os.getenv('HF_ENDPOINT', '')


class BGEEmbedding(Embeddings):

    def __init__(self, path=None, model_name=None):
        super().__init__()
        path = path or BGE_CACHE_DIR
        model_name = model_name or BGE_MODEL_NAME

        if not os.path.isdir(path) or not os.listdir(path):
            logger.info(f'正在下载嵌入模型 {model_name} 到 {path} ...')
            os.makedirs(path, exist_ok=True)
            if HF_ENDPOINT:
                os.environ['HF_ENDPOINT'] = HF_ENDPOINT
            temp = SentenceTransformer(model_name)
            temp.save(path)

        self.model = SentenceTransformer(path)

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        embeddings = self.model.encode(texts, normalize_embeddings=True)
        return embeddings.tolist()

    def embed_query(self, text: str) -> list[float]:
        embeddings = self.model.encode([text], normalize_embeddings=True)
        return embeddings.tolist()[0]


def get_embeddings() -> Embeddings:
    return BGEEmbedding(path=BGE_CACHE_DIR)


@lru_cache(maxsize=1)
def _get_vector_db():
    logger.info('加载向量数据库')
    return Chroma(
        persist_directory=DB_DIR,
        embedding_function=get_embeddings(),
        collection_name=COLLECTION_NAME,
    )


def _ensure_vector_db():
    db_file = os.path.join(DB_DIR, 'chroma.sqlite3') if DB_DIR else ''
    if DB_DIR and os.path.isfile(db_file):
        logger.info('向量库已存在，跳过构建')
        return

    logger.info('首次构建向量库')

    DOC_URL = os.getenv('DOC_URL', 'https://ffmpeg.org/ffmpeg-all.html')

    from app.build_vector_db import fetch_and_chunk
    chunks = fetch_and_chunk(DOC_URL)
    if not chunks:
        logger.warning('警告: 未获取到文档内容，向量库构建失败')
        return

    if DB_DIR and os.path.isdir(DB_DIR):
        shutil.rmtree(DB_DIR)

    embeddings = get_embeddings()
    Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=DB_DIR,
        collection_name=COLLECTION_NAME,
    )
    logger.info('向量库构建完成')


def get_text(question: str):
    logger.info('向量检索')
    logger.info(f'检索内容：{question[:200]}')
    try:
        result = _get_vector_db().similarity_search(query=question, k=20)
        return [doc.page_content for doc in result]
    except Exception as e:
        return f'查询失败，原因:\n{e}'


# ── ffprobe 知识库（ffprobe-all.html） ──

@lru_cache(maxsize=1)
def _get_probe_vector_db():
    logger.info('加载 ffprobe 向量数据库')
    return Chroma(
        persist_directory=DB_DIR,
        embedding_function=get_embeddings(),
        collection_name=PROBE_COLLECTION_NAME,
    )


def _ensure_probe_vector_db():
    db_file = os.path.join(DB_DIR, 'chroma.sqlite3') if DB_DIR else ''
    if DB_DIR and os.path.isfile(db_file):
        try:
            collections = [c.name for c in _get_vector_db()._client.list_collections()]
            if PROBE_COLLECTION_NAME in collections:
                logger.info('ffprobe 向量库已存在，跳过构建')
                return
        except Exception as e:
            logger.warning(f'检查 ffprobe 向量库失败：{e}，跳过构建避免重复')
            return

    logger.info('首次构建 ffprobe 向量库')

    PROBE_DOC_URL = os.getenv('PROBE_DOC_URL', 'https://ffmpeg.org/ffprobe-all.html')

    from app.build_vector_db import fetch_and_chunk
    chunks = fetch_and_chunk(PROBE_DOC_URL)
    if not chunks:
        logger.warning('警告: 未获取到 ffprobe 文档内容，向量库构建失败')
        return

    embeddings = get_embeddings()
    Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=DB_DIR,
        collection_name=PROBE_COLLECTION_NAME,
    )
    logger.info('ffprobe 向量库构建完成')


def get_probe_text(question: str):
    logger.info('ffprobe 向量检索')
    logger.info(f'检索内容：{question[:200]}')
    try:
        result = _get_probe_vector_db().similarity_search(query=question, k=20)
        return [doc.page_content for doc in result]
    except Exception as e:
        return f'查询失败，原因:\n{e}'


if __name__ == '__main__':
    result = get_text('how to invert colors of an image?')
    for i, doc in enumerate(result, 1):
        logger.info(f'来源[{i}]')
        logger.info(f'内容{doc[:50]}')
